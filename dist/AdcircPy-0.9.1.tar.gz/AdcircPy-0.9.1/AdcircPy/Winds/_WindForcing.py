

class _WindForcing(object):
    pass
